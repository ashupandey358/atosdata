package com.atos.projectQandA.qandaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QandaprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(QandaprojectApplication.class, args);
	}

}
