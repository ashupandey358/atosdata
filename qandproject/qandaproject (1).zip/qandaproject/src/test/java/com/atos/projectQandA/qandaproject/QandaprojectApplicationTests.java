package com.atos.projectQandA.qandaproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QandaprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
