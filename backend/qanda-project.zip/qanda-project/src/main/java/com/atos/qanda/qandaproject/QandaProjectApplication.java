package com.atos.qanda.qandaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QandaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(QandaProjectApplication.class, args);
	}

}
