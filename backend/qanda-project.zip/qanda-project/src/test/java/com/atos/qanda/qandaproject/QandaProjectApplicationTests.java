package com.atos.qanda.qandaproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QandaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
